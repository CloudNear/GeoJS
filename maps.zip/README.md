# googlemapapi
This code will help you to understand how to apply a google map for your website. 
No framework use just JQuery and JavaScript.
