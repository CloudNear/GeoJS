<html>

<head>
    <title>Simple goole Map</title>
    <meta name="viewport" content="initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css">
    <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.0.3.js"></script>
    <meta charset="utf-8">
    <style>
        .gm-style .gm-style-iw {
           width: 230px;
        }
    </style>
</head>

<body>
    <div>
        <p onclick="myfunc()">hello</p>
    </div>
    <div id="map-canvas" style="width: 800px; height: 500px;">
    </div>

</body>

</html>
<script type="text/javascript">
var map;
var latlng;
var infowindow;

$(document).ready(function() {
    //get data set from the backend in a json structure
    var data = [{
            "description": "Jl. Ipik Gandamanah No.303/15, Ciseureuh, Kec. Purwakarta, Kabupaten Purwakarta, Jawa Barat 41118",
            "location": "Gadgetcare",
            "latitude": "-6.525380995280063",
            "longitude": "107.45837665191839",
            "linkdirect": "gXdHweiEJwiCgCb76"
        }, 
        {
            "description": " Barat 41118",
            "location": "Gadgetcare",
            "latitude": "51.065453",
            "longitude": "-114.088841",
            "linkdirect": "gXdHweiEJwiCgCb76"
        }
    ]
    //if backend servie ready
    // $.ajax({ //library for JS help front-end to talk back-end, without having to reload the page
    //   url: "HelpMapper-backend.php",
    //   async: true,
    //   dataType: 'json', // is a language
    //   success: function (data) {
    //     console.log(data);
    //     ViewCustInGoogleMap(data);
    //   }
    // }); 
    // console.log(data);
    ViewCustInGoogleMap(data);
});

function ViewCustInGoogleMap(data) {
    var gm = google.maps; //create instance of google map
    //add initial map option
    var mapOptions = {
        center: new google.maps.LatLng(-6.5252743933606, 107.45788316879054), // Coimbatore = (11.0168445, 76.9558321)
        zoom: 9,
        //mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    //bine html tag to show the google map and bind mapoptions
    map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
    //create instance of google information windown
    infowindow = new google.maps.InfoWindow();
    var marker, i;
    // var MarkerImg = "https://maps.gstatic.com/intl/en_us/mapfiles/markers2/measle.png";
    // var MarkerImg2 = "https://maps.gstatic.com/intl/en_us/mapfiles/markers2/measle_blue.png";

    //loop through all the locations and point the mark in the google map
    for (var i = 0; i < data.length; i++) {
        marker = new gm.Marker({
            position: new gm.LatLng(data[i]['latitude'], data[i]['longitude']),
            map: map,
            // icon: MarkerImg
        });

  
        //add info for popup tooltip
        google.maps.event.addListener(
            marker,
            'click',
            (
                function(marker, i) {
                    return function() {
                        infowindow.setContent(data[i]['location'] +"<br>"+data[i]['description']+"<br>"+"<a href='https://goo.gl/maps/"+data[i]['linkdirect']+"' target='_blank()'>here</a>");
                        infowindow.open(map, marker);
                    };
                }
            )(marker, i)

        );
    }

    
        console.log(marker);
    

}
function myfunc(){
    myfunczx();
}


</script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD5wynsTZJ35Nul1K_mb0TIMm0lyvtrHiA&amp;region=id" type="text/javascript"></script>